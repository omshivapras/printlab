# Alt Print — Backend API

Production-grade REST API for the Alt Print mobile app (Android & iOS).
Built with Node.js, Express 5, PostgreSQL, and Drizzle ORM.

---

## Stack

- **Runtime:** Node.js 24, TypeScript
- **Framework:** Express 5
- **Database:** PostgreSQL + Drizzle ORM
- **Validation:** Zod v4

---

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Environment variables
Create a `.env` file:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/altprint
PORT=8080
NODE_ENV=production
```

### 3. Push database schema
```bash
npm run db:push
```

### 4. Run the server
```bash
npm run dev        # development
npm run start      # production
```

---

## API Endpoints

Base URL: `https://your-domain.com/api`

---

### System Config (for mobile app to read on startup)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/system/config` | Full platform state + all feature flags |

**GET /api/system/config — Response:**
```json
{
  "appEnabled": true,
  "maintenanceMode": false,
  "emergencyLock": false,
  "globalFeatures": {
    "black_white_print": true,
    "color_print": true,
    "spiral_binding": true,
    "delivery": true,
    "front_back_printing": true,
    "bulk_orders": true,
    "payment_upi": true,
    "payment_card": true,
    "payment_cod": true,
    "login_register": true
  }
}
```

Mobile app should call this on every startup. If `appEnabled` is false, show "App unavailable" screen. If `maintenanceMode` is true, show maintenance screen.

---

### Super Admin Endpoints (Mother Control — Boss Only)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/super-admin/status` | Platform on/off/maintenance status |
| PUT | `/api/super-admin/app` | Turn app on/off, maintenance, emergency lock |
| GET | `/api/super-admin/features` | All global feature flags |
| PUT | `/api/super-admin/features/:featureName` | Enable/disable a global feature |
| GET | `/api/super-admin/shops` | All registered shops |
| POST | `/api/super-admin/shops` | Register a new shop |
| PUT | `/api/super-admin/shops/:shopId` | Enable/disable a specific shop |
| GET | `/api/super-admin/audit-log` | Full audit log of all admin actions |

**PUT /api/super-admin/app — Body:**
```json
{ "appEnabled": false }
{ "maintenanceMode": true }
{ "emergencyLock": true }
```

**PUT /api/super-admin/features/:featureName — Body:**
```json
{ "enabled": false }
```

Feature names: `black_white_print`, `color_print`, `spiral_binding`, `delivery`,
`front_back_printing`, `bulk_orders`, `payment_upi`, `payment_card`, `payment_cod`, `login_register`

---

### Shop Admin Endpoints (Per-Shop Control)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/shop-admin/:shopId/features` | All features for this shop + globally disabled list |
| PUT | `/api/shop-admin/:shopId/features/:featureName` | Enable/disable a feature for this shop |

**GET /api/shop-admin/:shopId/features — Response:**
```json
{
  "shop": {
    "id": "shop-001",
    "name": "PrintZone - MG Road",
    "ownerEmail": "mgroad@altprint.in",
    "enabled": true,
    "createdAt": "2026-05-25T06:05:45.162Z"
  },
  "features": [
    { "featureName": "black_white_print", "label": "Black & White Printing", "enabled": true, "scope": "shop", ... },
    { "featureName": "color_print", "label": "Color Printing", "enabled": false, "scope": "shop", ... }
  ],
  "globallyDisabled": ["color_print"]
}
```

`globallyDisabled` = features turned off by Super Admin. The mobile app should hide/disable these options regardless of the shop-level setting.

**PUT /api/shop-admin/:shopId/features/:featureName — Body:**
```json
{ "enabled": false }
```

Note: Shop admin cannot re-enable a feature that is globally disabled by Super Admin. The API returns HTTP 403 in that case.

---

## Mobile App Integration Guide

### On App Startup (React Native)
```javascript
const config = await fetch('https://your-api.com/api/system/config').then(r => r.json());

if (!config.appEnabled) {
  // Show "App unavailable" screen
}
if (config.maintenanceMode) {
  // Show maintenance screen
}

// Store config globally for UI use
global.altPrintConfig = config;
```

### Show/Hide Print Options Based on Shop Features
```javascript
const shopData = await fetch(`https://your-api.com/api/shop-admin/${shopId}/features`).then(r => r.json());

const isEnabled = (featureName) => {
  if (shopData.globallyDisabled.includes(featureName)) return false;
  const flag = shopData.features.find(f => f.featureName === featureName);
  return flag ? flag.enabled : true;
};

// Usage in UI:
// Show B&W print button only if enabled
if (isEnabled('black_white_print')) { /* render button */ }
```

---

## Database Tables

| Table | Purpose |
|-------|---------|
| `system_config` | Single row — app on/off, maintenance, emergency lock |
| `shops` | All registered shops |
| `feature_flags` | Global and per-shop feature toggles |
| `audit_log` | Immutable record of every admin action |

---

## Control Panel (Web Dashboard)

Two web URLs for admin control:

| URL | Who uses it |
|-----|-------------|
| `/` | Super Admin — full platform control |
| `/shop/:shopId` | Shop Admin — controls only their shop |

---

## Security Note

In production, protect all `/super-admin/*` and `/shop-admin/*` routes with JWT authentication and role-based access control before going live.
