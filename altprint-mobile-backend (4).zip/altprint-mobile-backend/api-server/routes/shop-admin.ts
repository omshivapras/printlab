import { Router } from "express";
import { db } from "@workspace/db";
import { featureFlagsTable, shopsTable, auditLogTable } from "@workspace/db";
import { eq, and, isNull } from "drizzle-orm";
import {
  GetShopFeaturesParams,
  UpdateShopFeatureParams,
  UpdateShopFeatureBody,
} from "@workspace/api-zod";

const router = Router();

const PRINT_FEATURES = [
  { featureName: "black_white_print", label: "Black & White Printing" },
  { featureName: "color_print", label: "Color Printing" },
  { featureName: "spiral_binding", label: "Spiral Binding" },
  { featureName: "delivery", label: "Delivery" },
  { featureName: "front_back_printing", label: "Front/Back Printing" },
  { featureName: "bulk_orders", label: "Bulk Orders" },
  { featureName: "payment_upi", label: "UPI Payment" },
  { featureName: "payment_card", label: "Card Payment" },
  { featureName: "payment_cod", label: "Cash on Delivery" },
  { featureName: "login_register", label: "Login / Register" },
];

async function writeAudit(actor: string, action: string, target: string, details?: string) {
  await db.insert(auditLogTable).values({ actor, action, target, details: details ?? null });
}

async function getGloballyDisabledFeatures(): Promise<string[]> {
  const globalFlags = await db
    .select()
    .from(featureFlagsTable)
    .where(and(eq(featureFlagsTable.scope, "global"), isNull(featureFlagsTable.shopId)));

  return globalFlags.filter((f) => !f.enabled).map((f) => f.featureName);
}

router.get("/shop-admin/:shopId/features", async (req, res) => {
  const paramsParsed = GetShopFeaturesParams.safeParse(req.params);
  if (!paramsParsed.success) {
    res.status(400).json({ error: "Invalid shop ID" });
    return;
  }
  const { shopId } = paramsParsed.data;

  const [shop] = await db.select().from(shopsTable).where(eq(shopsTable.id, shopId)).limit(1);
  if (!shop) {
    res.status(404).json({ error: "Shop not found" });
    return;
  }

  const shopFlags = await db
    .select()
    .from(featureFlagsTable)
    .where(and(eq(featureFlagsTable.scope, "shop"), eq(featureFlagsTable.shopId, shopId)));

  const shopFlagMap = new Map(shopFlags.map((f) => [f.featureName, f]));

  const features = PRINT_FEATURES.map((feature, index) => {
    const existing = shopFlagMap.get(feature.featureName);
    if (existing) {
      return {
        id: existing.id,
        featureName: existing.featureName,
        label: existing.label,
        enabled: existing.enabled,
        scope: existing.scope,
        shopId: existing.shopId,
        updatedAt: existing.updatedAt.toISOString(),
      };
    }
    return {
      id: -(index + 1),
      featureName: feature.featureName,
      label: feature.label,
      enabled: true,
      scope: "shop" as const,
      shopId,
      updatedAt: new Date().toISOString(),
    };
  });

  const globallyDisabled = await getGloballyDisabledFeatures();

  res.json({
    shop: {
      id: shop.id,
      name: shop.name,
      ownerEmail: shop.ownerEmail,
      enabled: shop.enabled,
      createdAt: shop.createdAt.toISOString(),
    },
    features,
    globallyDisabled,
  });
});

router.put("/shop-admin/:shopId/features/:featureName", async (req, res) => {
  const paramsParsed = UpdateShopFeatureParams.safeParse(req.params);
  const bodyParsed = UpdateShopFeatureBody.safeParse(req.body);
  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }
  const { shopId, featureName } = paramsParsed.data;
  const { enabled } = bodyParsed.data;

  const globallyDisabled = await getGloballyDisabledFeatures();
  if (globallyDisabled.includes(featureName) && enabled) {
    res.status(403).json({
      error: `Feature "${featureName}" is globally disabled by Super Admin. Cannot re-enable at shop level.`,
    });
    return;
  }

  const [shop] = await db.select().from(shopsTable).where(eq(shopsTable.id, shopId)).limit(1);
  if (!shop) {
    res.status(404).json({ error: "Shop not found" });
    return;
  }

  const existing = await db
    .select()
    .from(featureFlagsTable)
    .where(
      and(
        eq(featureFlagsTable.featureName, featureName),
        eq(featureFlagsTable.scope, "shop"),
        eq(featureFlagsTable.shopId, shopId)
      )
    )
    .limit(1);

  const featureDef = PRINT_FEATURES.find((f) => f.featureName === featureName);
  const label = featureDef?.label ?? featureName.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

  let flag;
  if (existing.length === 0) {
    const [created] = await db
      .insert(featureFlagsTable)
      .values({ featureName, label, enabled, scope: "shop", shopId, updatedAt: new Date() })
      .returning();
    flag = created;
  } else {
    const [updated] = await db
      .update(featureFlagsTable)
      .set({ enabled, updatedAt: new Date() })
      .where(eq(featureFlagsTable.id, existing[0].id))
      .returning();
    flag = updated;
  }

  await writeAudit(
    `shop_admin:${shopId}`,
    enabled ? "ENABLE_FEATURE" : "DISABLE_FEATURE",
    featureName,
    `shop: ${shopId}`
  );

  res.json({
    id: flag.id,
    featureName: flag.featureName,
    label: flag.label,
    enabled: flag.enabled,
    scope: flag.scope,
    shopId: flag.shopId,
    updatedAt: flag.updatedAt.toISOString(),
  });
});

export default router;
