import { Router } from "express";
import { db } from "@workspace/db";
import { systemConfigTable, featureFlagsTable } from "@workspace/db";
import { eq, and, isNull } from "drizzle-orm";

const router = Router();

router.get("/system/config", async (req, res) => {
  const [config] = await db.select().from(systemConfigTable).limit(1);
  const globalFlags = await db
    .select()
    .from(featureFlagsTable)
    .where(and(eq(featureFlagsTable.scope, "global"), isNull(featureFlagsTable.shopId)));

  const globalFeatures: Record<string, boolean> = {};
  for (const flag of globalFlags) {
    globalFeatures[flag.featureName] = flag.enabled;
  }

  res.json({
    appEnabled: config?.appEnabled ?? true,
    maintenanceMode: config?.maintenanceMode ?? false,
    emergencyLock: config?.emergencyLock ?? false,
    globalFeatures,
  });
});

export default router;
