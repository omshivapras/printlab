import { Router } from "express";
import { db } from "@workspace/db";
import {
  systemConfigTable,
  featureFlagsTable,
  shopsTable,
  auditLogTable,
} from "@workspace/db";
import { eq, and, isNull, desc } from "drizzle-orm";
import { randomUUID } from "crypto";
import {
  UpdateAppStateBody,
  UpdateGlobalFeatureBody,
  UpdateGlobalFeatureParams,
  CreateShopBody,
  UpdateShopStatusBody,
  UpdateShopStatusParams,
  GetAuditLogQueryParams,
} from "@workspace/api-zod";

const router = Router();

async function ensureSystemConfig() {
  const [existing] = await db.select().from(systemConfigTable).limit(1);
  if (!existing) {
    const [created] = await db
      .insert(systemConfigTable)
      .values({ appEnabled: true, maintenanceMode: false, emergencyLock: false })
      .returning();
    return created;
  }
  return existing;
}

async function writeAudit(actor: string, action: string, target: string, details?: string) {
  await db.insert(auditLogTable).values({ actor, action, target, details: details ?? null });
}

router.get("/super-admin/status", async (req, res) => {
  const config = await ensureSystemConfig();
  res.json({
    appEnabled: config.appEnabled,
    maintenanceMode: config.maintenanceMode,
    emergencyLock: config.emergencyLock,
    updatedAt: config.updatedAt.toISOString(),
  });
});

router.put("/super-admin/app", async (req, res) => {
  const parsed = UpdateAppStateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const config = await ensureSystemConfig();
  const updates: Partial<typeof systemConfigTable.$inferInsert> = {};
  const { appEnabled, maintenanceMode, emergencyLock } = parsed.data;
  if (appEnabled !== undefined) updates.appEnabled = appEnabled;
  if (maintenanceMode !== undefined) updates.maintenanceMode = maintenanceMode;
  if (emergencyLock !== undefined) updates.emergencyLock = emergencyLock;
  updates.updatedAt = new Date();

  const [updated] = await db
    .update(systemConfigTable)
    .set(updates)
    .where(eq(systemConfigTable.id, config.id))
    .returning();

  await writeAudit(
    "super_admin",
    "UPDATE_APP_STATE",
    "system",
    JSON.stringify(parsed.data)
  );

  res.json({
    appEnabled: updated.appEnabled,
    maintenanceMode: updated.maintenanceMode,
    emergencyLock: updated.emergencyLock,
    updatedAt: updated.updatedAt.toISOString(),
  });
});

router.get("/super-admin/features", async (req, res) => {
  const flags = await db
    .select()
    .from(featureFlagsTable)
    .where(and(eq(featureFlagsTable.scope, "global"), isNull(featureFlagsTable.shopId)));

  res.json(
    flags.map((f) => ({
      id: f.id,
      featureName: f.featureName,
      label: f.label,
      enabled: f.enabled,
      scope: f.scope,
      shopId: f.shopId,
      updatedAt: f.updatedAt.toISOString(),
    }))
  );
});

router.put("/super-admin/features/:featureName", async (req, res) => {
  const paramsParsed = UpdateGlobalFeatureParams.safeParse(req.params);
  const bodyParsed = UpdateGlobalFeatureBody.safeParse(req.body);
  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }
  const { featureName } = paramsParsed.data;
  const { enabled } = bodyParsed.data;

  const existing = await db
    .select()
    .from(featureFlagsTable)
    .where(
      and(
        eq(featureFlagsTable.featureName, featureName),
        eq(featureFlagsTable.scope, "global"),
        isNull(featureFlagsTable.shopId)
      )
    )
    .limit(1);

  let flag;
  if (existing.length === 0) {
    const [created] = await db
      .insert(featureFlagsTable)
      .values({
        featureName,
        label: featureName.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
        enabled,
        scope: "global",
        shopId: null,
        updatedAt: new Date(),
      })
      .returning();
    flag = created;
  } else {
    const [updated] = await db
      .update(featureFlagsTable)
      .set({ enabled, updatedAt: new Date() })
      .where(eq(featureFlagsTable.id, existing[0].id))
      .returning();
    flag = updated;
  }

  await writeAudit("super_admin", enabled ? "ENABLE_FEATURE" : "DISABLE_FEATURE", featureName);

  res.json({
    id: flag.id,
    featureName: flag.featureName,
    label: flag.label,
    enabled: flag.enabled,
    scope: flag.scope,
    shopId: flag.shopId,
    updatedAt: flag.updatedAt.toISOString(),
  });
});

router.get("/super-admin/shops", async (req, res) => {
  const shops = await db.select().from(shopsTable);
  res.json(
    shops.map((s) => ({
      id: s.id,
      name: s.name,
      ownerEmail: s.ownerEmail,
      enabled: s.enabled,
      createdAt: s.createdAt.toISOString(),
    }))
  );
});

router.post("/super-admin/shops", async (req, res) => {
  const parsed = CreateShopBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const { name, ownerEmail } = parsed.data;
  const id = randomUUID();

  const [shop] = await db
    .insert(shopsTable)
    .values({ id, name, ownerEmail, enabled: true })
    .returning();

  await writeAudit("super_admin", "CREATE_SHOP", id, name);

  res.status(201).json({
    id: shop.id,
    name: shop.name,
    ownerEmail: shop.ownerEmail,
    enabled: shop.enabled,
    createdAt: shop.createdAt.toISOString(),
  });
});

router.put("/super-admin/shops/:shopId", async (req, res) => {
  const paramsParsed = UpdateShopStatusParams.safeParse(req.params);
  const bodyParsed = UpdateShopStatusBody.safeParse(req.body);
  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }
  const { shopId } = paramsParsed.data;
  const { enabled } = bodyParsed.data;

  const [shop] = await db
    .update(shopsTable)
    .set({ enabled })
    .where(eq(shopsTable.id, shopId))
    .returning();

  if (!shop) {
    res.status(404).json({ error: "Shop not found" });
    return;
  }

  await writeAudit("super_admin", enabled ? "ENABLE_SHOP" : "DISABLE_SHOP", shopId, shop.name);

  res.json({
    id: shop.id,
    name: shop.name,
    ownerEmail: shop.ownerEmail,
    enabled: shop.enabled,
    createdAt: shop.createdAt.toISOString(),
  });
});

router.get("/super-admin/audit-log", async (req, res) => {
  const queryParsed = GetAuditLogQueryParams.safeParse(req.query);
  const limit = queryParsed.success ? (queryParsed.data.limit ?? 50) : 50;

  const entries = await db
    .select()
    .from(auditLogTable)
    .orderBy(desc(auditLogTable.createdAt))
    .limit(limit);

  res.json(
    entries.map((e) => ({
      id: e.id,
      actor: e.actor,
      action: e.action,
      target: e.target,
      details: e.details,
      createdAt: e.createdAt.toISOString(),
    }))
  );
});

export default router;
