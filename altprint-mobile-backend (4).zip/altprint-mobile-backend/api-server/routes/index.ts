import { Router, type IRouter } from "express";
import healthRouter from "./health";
import systemRouter from "./system";
import superAdminRouter from "./super-admin";
import shopAdminRouter from "./shop-admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(systemRouter);
router.use(superAdminRouter);
router.use(shopAdminRouter);

export default router;
