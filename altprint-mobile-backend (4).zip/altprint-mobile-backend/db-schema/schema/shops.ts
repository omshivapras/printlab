import { pgTable, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const shopsTable = pgTable("shops", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  ownerEmail: text("owner_email").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Shop = typeof shopsTable.$inferSelect;
export type InsertShop = typeof shopsTable.$inferInsert;
