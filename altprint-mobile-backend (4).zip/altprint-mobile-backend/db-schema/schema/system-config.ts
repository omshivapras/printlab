import { pgTable, serial, boolean, timestamp } from "drizzle-orm/pg-core";

export const systemConfigTable = pgTable("system_config", {
  id: serial("id").primaryKey(),
  appEnabled: boolean("app_enabled").notNull().default(true),
  maintenanceMode: boolean("maintenance_mode").notNull().default(false),
  emergencyLock: boolean("emergency_lock").notNull().default(false),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type SystemConfig = typeof systemConfigTable.$inferSelect;
