import { pgTable, serial, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const featureFlagsTable = pgTable("feature_flags", {
  id: serial("id").primaryKey(),
  featureName: text("feature_name").notNull(),
  label: text("label").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  scope: text("scope").notNull().default("global"), // "global" | "shop"
  shopId: text("shop_id"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type FeatureFlag = typeof featureFlagsTable.$inferSelect;
export type InsertFeatureFlag = typeof featureFlagsTable.$inferInsert;
